input {
    tcp {
        port => 18116
        id => "input_vmware_vcenter"
        add_field => {
            "[@metadata][type]" => "vmware_vcenter"
             "__pipline" => "vmware_vcenter"
            "log_source_type" => "vmware_vcenter"
            #"log_source_device" => "VMware vCenter"
        }
    }
}

filter {
    if "vmware_vcenter" == [@metadata][type] {
        # 第一步：解析基本字段
        grok {
            id => "grok_parser_vmware_vcenter"
            match => {
                "message" => [
                    "<%{INT:syslog_priority}>%{NUMBER:syslog_version} %{TIMESTAMP_ISO8601:log_time} %{HOSTNAME:syslog_hostname} %{NOTSPACE:component} - - - %{TIMESTAMP_ISO8601} %{WORD:log_level} %{WORD:process}\[%{NUMBER:thread_id}\] %{GREEDYDATA:log_details}",
                    "<%{INT:syslog_priority}>%{NUMBER:syslog_version} %{TIMESTAMP_ISO8601:log_time} %{HOSTNAME:syslog_hostname} %{NOTSPACE:component} - - - \[%{DATA:gc_details}\] %{GREEDYDATA:gc_times}"
                ]
            }
        }

        if [log_details]{
            
            # 第二步：解析 log_details 字段中的详细信息
            grok {
                id => "grok_parser_log_details"
                match => {
                    "log_details" => [
                        "\[%{DATA:originator}\] %{TIMESTAMP_ISO8601:time} %{WORD:method} %{URIPATHPARAM:uri} %{NOTSPACE:protocol} %{INT:response_code} %{NOTSPACE:via_upstream} - %{NUMBER:request_size} %{NUMBER:response_size} %{NUMBER:duration} %{NUMBER:tcp_connections} %{NUMBER:unknown_field} %{IP:src_ip}:%{INT:src_port} %{IP:dst_ip}:%{INT:dst_port} %{IP:local_ip1}:%{INT:local_port1} %{IP:local_ip2}:%{INT:local_port2}",
                        "\[%{DATA:originator}\] \[%{WORD:vpxlro}\] -- %{WORD:lro_action} %{NOTSPACE:lro_id}"
                    ]
                }
            }
            mutate {
                remove_field => ["log_details"]
            }
        }

        mutate {
            id => "filter_vmware_vcenter"
            add_field => {
                "__source" => "vmware_vcenter"
                "log_source_device" => "VMware vCenter @ %{[syslog_hostname]}"
            }
            remove_field => ["event"]
            remove_field => ["log_details"]
        }
    }
}

output {
    if "vmware_vcenter" == [@metadata][type] {
        kafka {
            id => "output_vmware_vcenter"
            bootstrap_servers => "sec-kafka-1.mdw.maribanksvc.com:9092,sec-kafka-2.mdw.maribanksvc.com:9092,sec-kafka-3.mdw.maribanksvc.com:9092"
            topic_id => "siem-raw-data"
            client_id => "kafka_vmware_vcenter_client"
            codec => json
        }
    }
}
