import json
import os

script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "crowdstrike_json_log.log")
output_file = os.path.join(script_dir, "crowdstrike.log")

with open(input_file) as fin, open(output_file, "w") as fout:
    for line in fin:
        line = line.strip()
        if line:  # skip empty lines
            try:
                data = json.loads(line)
                if "message" in data:
                    fout.write(data["message"] + "\n")
            except json.JSONDecodeError:
                continue 